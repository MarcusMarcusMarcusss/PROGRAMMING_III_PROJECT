﻿namespace MusicPlayer_Project
{
    //create a static class that stores username
    public static class LoginInfo
    {
        public static string UserName;
    }
}
